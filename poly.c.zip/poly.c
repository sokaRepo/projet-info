#include <stdio.h>
#include <stdlib.h>

#include "src/struct.h"
/*
typedef struct developpe{
	float img;
	float real;
	int coeff;
	int pow;
	struct developpe *next;
}developpe;

typedef developpe * dev;

typedef struct factorise{
	float img;
	float real;
	float coeff;
	struct factorise *next;
}factorise;

typedef factorise * fact;

typedef struct polynome{
	struct factorise factorise;
	struct developpe developpee;
}polynome;

*/

void createDevPoly(dev *pl)
{
	int nombre;
	int i=0;
	//printf("BEGIN creer 1\n");
	dev l= (*pl) = malloc(sizeof(developpe));
	//printf("BEGIN creer 2\n");
	l->next=NULL;
	//printf("BEGIN creer 3\n");
	dev queue=malloc(sizeof(developpe));
	queue=l;
	queue->pow=1;
	queue->coeff=2;
	nombre=3;
	for (i=2; i<6; i++)
	{
		//printf("i = %d\n", i);
		//printf("a\n");
		queue->next=malloc(sizeof(developpe));
		queue=queue->next;
		queue->pow=i;
		queue->coeff=nombre;
		queue->next=NULL;
		nombre++;
	}
}

void createComplexPoly(dev *pl)
{
	int nombre;
	int i=0;
	//printf("BEGIN creer 1\n");
	dev l= (*pl) = malloc(sizeof(developpe));
	//printf("BEGIN creer 2\n");
	l->next=NULL;
	//printf("BEGIN creer 3\n");
	dev queue=malloc(sizeof(developpe));
	queue=l;
	queue->pow=1;
	queue->img = 1;
	queue->real=2;
	nombre=3;
	for (i=2; i<6; i++)
	{
		//printf("i = %d\n", i);
		//printf("a\n");
		queue->next=malloc(sizeof(developpe));
		queue=queue->next;
		queue->pow=i;
		queue->img=nombre;
		queue->real=nombre;
		queue->next=NULL;
		nombre++;
	}
}

void createComplexPolyFact(fact *pl)
{
	int nombre;
	int i=0;
	//printf("BEGIN creer 1\n");
	fact l= (*pl) = malloc(sizeof(fact));
	//printf("BEGIN creer 2\n");
	l->next=NULL;
	//printf("BEGIN creer 3\n");
	fact queue=malloc(sizeof(fact));
	queue=l;
	queue->coeff=1;
	queue->img = 1;
	queue->real=2;
	nombre=3;
	for (i=2; i<6; i++)
	{
		//printf("i = %d\n", i);
		//printf("a\n");
		queue->next=malloc(sizeof(fact));
		queue=queue->next;
		queue->coeff=i;
		queue->img=nombre;
		queue->real=nombre;
		queue->next=NULL;
		nombre++;
	}
}


void printDevPoly(dev l)
{
	//int i;
	while (l != NULL)
	{
		printf ("%dX^%d+", l->coeff, l->pow);
		l=l->next;
		if(l->next == NULL) {
			printf ("%dX^%d", l->coeff, l->pow);
			l=l->next;
		}

	}
	printf("\n");
}

void printComplexPoly(dev l)
{
	//int i;
	while (l != NULL)
	{
		
		if(l->next == NULL) {
			printf ("(%lf - %lfi)Z^%d", l->real, l->img, l->pow);
			l=l->next;
		}else {
			printf ("(%lf - %lfi)Z^%d + ", l->real, l->img, l->pow);
			l=l->next;
		}

	}
	printf("\n");
}


void printComplexPolyFact(fact l)
{
	//int i;
	while (l != NULL)
	{
		
		if(l->real > 0 && l->img > 0) 
			printf ("(%lfz + %lfi + %lf)", l->real, l->img, l->coeff);
		else if(l->real < 0 && l->img < 0)
			printf ("(%lfz - %lfi - %lf)", l->real, l->img, l->coeff);
		else if(l->real > 0 && l->img < 0)
			printf ("(%lfz - %lfi + %lf)", l->real, l->img, l->coeff);
		else if(l->real < 0 && l->img > 0)
			printf ("(%lfz + %lfi - %lf)", l->real, l->img, l->coeff);
		else
			printf ("(%lfz)", l->coeff);
		l = l->next;
	}
	printf("\n");
}


void addPoly(dev poly1, dev poly2, dev * result) {
	dev polyResult = (*result) = malloc(sizeof(dev));
	polyResult->next = NULL;
	*result = polyResult;

	while(poly1 && poly2) {
		if(poly1->pow > poly2->pow) {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img;
			polyResult->real = poly1->real;
			poly1 = polyResult->next;
		}
		else if(poly1->pow < poly2->pow) {
			polyResult->pow = poly2->pow;
			polyResult->img = poly2->img;
			polyResult->real = poly2->real;
			poly2 = polyResult->next;	
		}
		else {
			polyResult->pow = poly1->pow;
			if(poly1->img + poly2->img == 0)
				polyResult = NULL;
			else
				polyResult->img = poly1->img + poly2->img;
			polyResult->real = poly1->real + poly2->real;
			poly1 = poly1->next;
			poly2 = poly2->next;
		}

		if(poly1 && poly2) {
            polyResult = polyResult->next = malloc(sizeof(dev));
            polyResult->next = NULL;
        }
	}

	
}

void multiplyPoly(dev poly1, dev poly2, dev * result) {
	dev polyResult = (*result) = malloc(sizeof(dev));
	polyResult->next = NULL;
	*result = polyResult;

	while(poly1 && poly2) {
		if(poly1->pow > poly2->pow) {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img;
			polyResult->real = poly1->real;
			poly1 = polyResult->next;
		}
		else if(poly1->pow < poly2->pow) {
			polyResult->pow = poly2->pow;
			polyResult->img = poly2->img;
			polyResult->real = poly2->real;
			poly2 = polyResult->next;	
		}
		else {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img * poly2->img;
			polyResult->real = poly1->real * poly2->real;
			poly1 = poly1->next;
			poly2 = poly2->next;
		}

		if(poly1 && poly2) {
            polyResult = polyResult->next = malloc(sizeof(dev));
            polyResult->next = NULL;
        }
	}

	
}

void soustractPoly(dev poly1, dev poly2, dev * result) {
	dev polyResult = (*result) = malloc(sizeof(dev));
	dev curr;
	dev pre;
	polyResult->next = NULL;
	*result = polyResult;

	while(poly1 && poly2) {
		curr = polyResult->next;
		pre = polyResult;

		if(poly1->pow > poly2->pow) {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img;
			polyResult->real = poly1->real;
			poly1 = poly1->next;
		}
		else if(poly1->pow < poly2->pow) {
			polyResult->pow = poly2->pow;
			polyResult->img = poly2->img;
			polyResult->real = poly2->real;
			poly2 = poly2->next;	
		}
		else {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img - poly2->img;
			polyResult->real = poly1->real - poly2->real;
			poly1 = poly1->next;
			poly2 = poly2->next;
		}
		if(polyResult->img == 0 && polyResult->real == 0) {
			pre->next = curr->next;
			free(curr);
		}
		if(poly1 && poly2) {
            polyResult = polyResult->next = malloc(sizeof(dev));
            polyResult->next = NULL;
        }

	}
	
}

void dividePoly(dev poly1, dev poly2, dev * result) {
	dev polyResult = (*result) = malloc(sizeof(dev));
	polyResult->next = NULL;
	*result = polyResult;

	while(poly1 && poly2) {
		if(poly1->pow > poly2->pow) {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img;
			polyResult->real = poly1->real;
			poly1 = polyResult->next;
		}
		else if(poly1->pow < poly2->pow) {
			polyResult->pow = poly2->pow;
			polyResult->img = poly2->img;
			polyResult->real = poly2->real;
			poly2 = polyResult->next;	
		}
		else {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img / poly2->img;
			polyResult->real = poly1->real / poly2->real;
			poly1 = poly1->next;
			poly2 = poly2->next;
		}

		if(poly1 && poly2) {
            polyResult = polyResult->next = malloc(sizeof(dev));
            polyResult->next = NULL;
        }
	}

	
}

int main ()
{
	
	dev poly1;
	dev poly2;
	dev poly3; // poly1 + poly2
	createComplexPoly(&poly1);
	createComplexPoly(&poly2);
	printf("1st poly: \n");
	printComplexPoly(poly1);
	printf("\n2nd poly: \n");
	printComplexPoly(poly2);
	soustractPoly(poly1, poly2, &poly3);
	printf("\nResult poly add:\n");
	printComplexPoly(poly3);
	/*
	fact poly1;
	createComplexPolyFact(&poly1);
	printf("Poly 1:\n");
	printComplexPolyFact(poly1);
	*/
	return 0;
}