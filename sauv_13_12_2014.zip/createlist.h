#ifndef CREATELIST
#define CREATELIST

void createComplexPoly(dev *pl);
void createComplexPolyFact(fact *pl);

#endif

