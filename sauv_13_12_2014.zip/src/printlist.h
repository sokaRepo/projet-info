#ifndef PRINTLIST
#define PRINTLIST

void printComplexPoly(dev l);
void printComplexPolyFact(fact l);

#endif