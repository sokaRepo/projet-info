#ifndef OPERATIONS
#define OPERATIONS

int getPolyLength(dev poly);
void swap_p(dev *p1, dev *p2);
void sortF(dev *poly);
void swapFloat(float* p_i, float* p_n);
void sortFloatArray(float array[], int len);
void swapInt(int* p_i, int* p_n);
void sortIntArray(int array[], int len);
void sortPoly(dev *poly);
void cleanPoly(dev *poly);
void addPoly(dev poly1, dev poly2, dev * result);
void multiplyPoly(dev poly1, dev poly2, dev * result);
void soustractPoly(dev poly1, dev poly2, dev * result);
void dividePoly(dev poly1, dev poly2, dev * result);

#endif