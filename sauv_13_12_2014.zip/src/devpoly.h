#ifndef DEVPOLY
#define DEVPOLY



void createDevPoly(dev *pl);
void printDevPoly(dev l);


#endif