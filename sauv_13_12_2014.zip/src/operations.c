#include <stdio.h>
#include <stdlib.h>
#include "struct.h"
#include "operations.h"
#include "debug.h"

int getPolyLength(dev poly) {
	int count = 0;
	while(poly) {
		count++;
		poly = poly->next;
	}
	return count;
}

void swap_p(dev *p1, dev *p2) {
	int tmp_pow;
	float tmp_real, tmp_img;
	tmp_pow = (*p1)->pow;
	tmp_img = (*p1)->img;
	tmp_real = (*p1)->real;
	(*p1)->pow = (*p2)->pow;
	(*p1)->img = (*p2)->img;
	(*p1)->real = (*p2)->real;
	(*p2)->pow = tmp_pow;
	(*p2)->img = tmp_img;
	(*p2)->real = tmp_real;

}

void sortF(dev *poly) {
	dev tmp = *poly;
	int len = getPolyLength(tmp);
	int i, n;
	dev save = *poly;
	dev cmp = tmp->next;
	for(i=0; i<len-1; i++) {
		for(n=0; n<len-1; n++) {
			if(cmp->pow < tmp->pow) {
				//printf("[DEBUG] Change %d and %d\n", cmp->pow, tmp->pow);
				swap_p(&cmp, &tmp);
			}
			cmp = cmp->next;
			tmp = tmp->next;
		}
		tmp = save;
		cmp = tmp->next;
	}
}
/*
void swapFloat(float* p_i, float* p_n) {
	float tmp;
	tmp = *p_i;
	*p_i = *p_n;
	*p_n = tmp;
}

void sortFloatArray(float array[], int len) {
	int i, n;
	for(n=0; n<len-1; n++) {
		for(i=0; i<len-1; i++) {
			if(array[i] > array[i+1])
				swapFloat(&array[i], &array[i+1]);
		}
	}
}

void swapInt(int* p_i, int* p_n) {
	int tmp;
	tmp = *p_i;
	*p_i = *p_n;
	*p_n = tmp;
}

void sortIntArray(int array[], int len) {
	int i, n;
	for(n=0; n<len-1; n++) {
		for(i=0; i<len-1; i++) {
			if(array[i] > array[i+1])
				swapInt(&array[i], &array[i+1]);
		}
	}
}

void printArray(float array[], int len) {
	int i;
	printf("Array: ");
	for(i=0; i<len; i++) {
		printf("%lf ", array[i]);
	}
	printf("\n");
}

void printArray2(int array[], int len) {
	int i;
	printf("Array: ");
	for(i=0; i<len; i++) {
		printf("%d ", array[i]);
	}
	printf("\n");
}
*/

/*
void sortPoly(dev *poly) {
	return ;
	
	float imgArray[20];
	float realArray[20];
	int powArray[20];
	dev tmp = (*poly);
	int len = getPolyLength(tmp);
	dev tmp2 = (*poly);
	int i = 0;
	int n = 0;
	//printf("[SORT] Begin\n");
	while(tmp) {
		imgArray[i] = tmp->img;
		realArray[i] = tmp->real;
		powArray[i] = tmp->pow;
		i++;
		tmp = tmp->next;
	}
	
	printf("----------------------------\n");
	blue("Elements of arrays: \n");
	printf("----------------------------\n");

	printArray(imgArray, len);
	printArray(realArray, len);
	printArray2(powArray, len);
	//printf("[SORT] Inter\n");
	
	sortFloatArray(imgArray, len);
	sortFloatArray(realArray, len);
	sortIntArray(powArray, len);
	
	printf("----------------------------\n");
	red("[SORT] After sort");
	printf("----------------------------\n");
	printArray(imgArray, len);
	printArray(realArray, len);
	printArray2(powArray, len);
	printf("-----------------------------\n");
	//printf("[SORT] Inter2\n");
	
	while(tmp2) {
		tmp2->img = imgArray[n];
		tmp2->real = realArray[n];
		tmp2->pow = powArray[n];
		tmp2 = tmp2->next;
		n++;
	}
	//printf("[SORT] End\n");
	

}
*/

/*

@ void cleanPoly->poly
Supprime tous les monomes nuls dans un polynome

*/

void cleanPoly(dev *poly) {
	/*
	dev tmp = *poly;
	dev curr, prev;
	if(!tmp) return ;
	if(tmp->img == 0 && tmp->real == 0) {
		printf("B Clean: %lf %lf %d\n", tmp->real, tmp->img, tmp->pow);
		curr = *poly;
		tmp = tmp->next;
		free(curr);
	}
	
	curr = tmp->next;
	prev = tmp;
	while(curr) {
		if(curr->img == 0 && curr->real == 0) {
			printf("B Clean: %lf %lf %d\n", curr->real, curr->img, curr->pow);
			prev->next = curr->next;
			free(curr);
		}
		else {
			prev = curr;
			curr = curr->next;
		}
	}
	*/
	dev tmp = *poly;
	dev curr;
	if(!tmp) return ;
	if(tmp->img == 0 && tmp->real == 0) {
		curr = *poly;
		*poly = (*poly)->next; 
		free(curr);
	}
	cleanPoly(&(*poly));

	
}


void addPoly(dev poly1, dev poly2, dev * result) {
	dev polyResult = (*result) = malloc(sizeof(dev));
	polyResult->next = NULL;
	*result = polyResult;

	while(poly1 && poly2) {
		if(poly1->pow > poly2->pow) {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img;
			polyResult->real = poly1->real;
			poly1 = polyResult->next;
		}
		else if(poly1->pow < poly2->pow) {
			polyResult->pow = poly2->pow;
			polyResult->img = poly2->img;
			polyResult->real = poly2->real;
			poly2 = polyResult->next;	
		}
		else {
			polyResult->pow = poly1->pow;
			if(poly1->img + poly2->img == 0)
				polyResult = NULL;
			else
				polyResult->img = poly1->img + poly2->img;
			polyResult->real = poly1->real + poly2->real;
			poly1 = poly1->next;
			poly2 = poly2->next;
		}

		if(poly1 && poly2) {
            polyResult = polyResult->next = malloc(sizeof(dev));
            polyResult->next = NULL;
        }
	}
	cleanPoly(&polyResult);

	
}

void multiplyPoly(dev poly1, dev poly2, dev * result) {
	dev polyResult = (*result) = malloc(sizeof(dev));
	polyResult->next = NULL;
	*result = polyResult;

	while(poly1 && poly2) {
		if(poly1->pow > poly2->pow) {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img;
			polyResult->real = poly1->real;
			poly1 = polyResult->next;
		}
		else if(poly1->pow < poly2->pow) {
			polyResult->pow = poly2->pow;
			polyResult->img = poly2->img;
			polyResult->real = poly2->real;
			poly2 = polyResult->next;	
		}
		else {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img * poly2->img;
			polyResult->real = poly1->real * poly2->real;
			poly1 = poly1->next;
			poly2 = poly2->next;
		}

		if(poly1 && poly2) {
            polyResult = polyResult->next = malloc(sizeof(dev));
            polyResult->next = NULL;
        }
	}
	cleanPoly(&polyResult);
	
}

void soustractPoly(dev poly1, dev poly2, dev * result) {
	dev polyResult = (*result) = malloc(sizeof(dev));
	polyResult->next = NULL;
	*result = polyResult;

	while(poly1 && poly2) {

		if(poly1->pow > poly2->pow) {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img;
			polyResult->real = poly1->real;
			poly1 = poly1->next;
		}
		else if(poly1->pow < poly2->pow) {
			polyResult->pow = poly2->pow;
			polyResult->img = poly2->img;
			polyResult->real = poly2->real;
			poly2 = poly2->next;	
		}
		else {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img - poly2->img;
			polyResult->real = poly1->real - poly2->real;
			poly1 = poly1->next;
			poly2 = poly2->next;
		}
		if(poly1 && poly2) {
            polyResult = polyResult->next = malloc(sizeof(dev));
            polyResult->next = NULL;
        }

	}
	cleanPoly(&(*result));
	
}



void dividePoly(dev poly1, dev poly2, dev * result) {
	dev polyResult = (*result) = malloc(sizeof(dev));
	polyResult->next = NULL;
	*result = polyResult;

	while(poly1 && poly2) {
		if(poly1->pow > poly2->pow) {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img;
			polyResult->real = poly1->real;
			poly1 = polyResult->next;
		}
		else if(poly1->pow < poly2->pow) {
			polyResult->pow = poly2->pow;
			polyResult->img = poly2->img;
			polyResult->real = poly2->real;
			poly2 = polyResult->next;	
		}
		else {
			polyResult->pow = poly1->pow;
			polyResult->img = poly1->img / poly2->img;
			polyResult->real = poly1->real / poly2->real;
			poly1 = poly1->next;
			poly2 = poly2->next;
		}

		if(poly1 && poly2) {
            polyResult = polyResult->next = malloc(sizeof(dev));
            polyResult->next = NULL;
        }
	}
	cleanPoly(&polyResult);
	
}