#ifndef CREATELIST
#define CREATELIST


void createComplexFromCmd(fact *pl);
void createComplexPoly(dev *pl);
void createComplexPolyFact(fact *pl);

#endif

