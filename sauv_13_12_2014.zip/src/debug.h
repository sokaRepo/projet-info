#ifndef COLOR
#define COLOR


void red(char* str);
void blue(char* str);

#endif